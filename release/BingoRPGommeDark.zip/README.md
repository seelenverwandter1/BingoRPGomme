# Bingo Ressourcepack

This Ressourcepack adds
- Custom Powder Snow Bucket
- Custom Azalea Leaves
- Low Fire
- Low Shield
- Clear Water
- Vanilla Tweaks